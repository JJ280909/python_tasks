

allow = False


while allow == False:
  check = input('What option do you want to pick, A, B or C?')
  if check == 'A' :
    allow == True
    print('A : Ammend')
  elif check == 'B':
    print('B : Bookings')
    allow == True
  elif  check == 'C':
    print('C : Cancel bookings')
    allow == True
  else:
    print('invalid choice')

 

 