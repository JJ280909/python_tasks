# Write a 'Guess the Number' Multiplayer Game. A primary school teacher wants to create
# a fun activity for their students to play when it is raining and they have to stay inside
# during break and lunch. Five pupils can play the game at once. Each player chooses a
# number between 1 and 100. Then a random number is generated. Whoever was furthest
# from the random number is out of the game. The four remaining players then pick a new
# number. This continues with one player being removed each round until only one player
# is left and they are the winner.
# - You will need to use loops to allow the users to enter their numbers.
# - You may wish to use subroutines to decompose the problem into separate rounds.
# - You will need to import the random library to generate a random number in each
# round.
# - You will need to compare each number to the randomly selected answer using
# comparison operators such as > and

import random

n1 = input('What is the name of player one?:')
n2 = input('What is the name of player two?:')
n3 = input('What is the name of player three?:')
n4 = input('What is the name of player four?:')
n5 = input('What is the name of player five?:')


names = [n1, n2, n3, n4, n5]


def game():
  guesses = []
  difference = []
  for i in names:
    print(i + ', choose your number:')
    guess = int(input('Guess:'))
    guesses.append(guess)
    
  magic_num = random.randint(1,100)

  for i in guesses:
    diff = abs(magic_num - i)
    difference.append(diff)
    
  big = (max(difference))
  print(big)
  print('The magic number was: ' + str(magic_num))
  
  
  ind = difference.index(big)
  who = names[ind]
  
  print(str(who + ' was furthest away froom the magic number by ' + str(big)))
  print()
  names.remove(who)

while len(names) > 1:
  game()
  
print('The winner is ' + str(''.join(names)))