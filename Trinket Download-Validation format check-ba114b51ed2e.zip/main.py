pcv = False

while pcv == False:
  pc = input('Enter product code:')
  if len (pc) == 5:
    charpart = pc[0:2]
    numpart = pc[2:5]
    if (charpart.isalpha()) and (numpart.isdigit()):
      print('valid code')
      pcv = True
  if pcv == False:
    print('Product code must be 2 letters then 3 numbers')