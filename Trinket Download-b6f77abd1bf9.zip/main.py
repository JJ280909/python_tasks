days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
print(days)

userday= input('What days are in the week?')

if userday in days:
  print('that is a day of the week')
else:
  print('Thatr is not a day of the weeek')
  