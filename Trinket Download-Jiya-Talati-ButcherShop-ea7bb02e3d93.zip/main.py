#setting variable
confirmation = False
#Putting everthing in a while loop so it repeats
while confirmation == False: 
  try:
    print('Welcome to Mr Blobby\'s Butchers')
    eggs = int(input('Scotch Eggs are 30p each. Enter the amount to order:'))#Finds out how many items needed of each food
    pies = int(input('Pork Pies are 80p each. Enter the amount to order:'))
    tarts = int(input('Quiche Tarts are £1.40 each. Enter the amount to order:'))
    print('You have selected ' + str(eggs) + ' scotch eggs, ' + str(pies)  # finds out whether the order is correct
    + ' pork pies and ' + str(tarts) + ' quiche tarts')
    ask = input('Is this your order? Yes/No?') # confirmation of order
    if ask.lower() == 'yes':  # makes sure that yes is accepted as Yes or yes
      confirmation == True
      print('Reciept\n ' + 'Scotch Eggs = ' + str(eggs) +  # prints reciept
      '\n Pork Pies = ' + str(pies) + 
      '\n Quiche Tarts = ' + str(tarts))
      eggscost = eggs * 0.30   # finds cost of items in pence
      piescost = pies * 0.80
      tartcost = tarts * 1.40
      total = eggscost + piescost + tartcost # finds total
      roundtotal = "{:.2f}".format(total) # makes total into 2 d.p
      print('Total cost = £' + str(roundtotal))
      finished = input('Are you finished with your order? Yes/No') # asks if the user wishes to order again
      if finished.lower() == 'no':
        print('Order again please')  # loops code back to start
      else:
        print('Goodbye, thank you for shopping at Mr Blobbys!!!!!!')
        next = input('Next Customer, do you want to order? Yes/No?')  # asks if there is another customer that wants to order
        if next.lower() == 'yes':
          print('')
        else:
          print('Okay, please stop loitering then.')
          break # ends the program
      
    else:
      print('Let me take your order again') # if items number is not accurate or buyer is not happy with items, the code starts again
  except:
    print('I am sorry, I do not understand what you said, let me take the order again') # if there is an error in input, the code will start again