finished = False
list = []
numbers = []
drinks = ['1) Lucozade', '2) Cherry Vinto', '3) Dr Pepper', '4) Sprite', '5) Tango Dango', '6) 7Up', '7) 7Up', '8) Coca Cola Original', '9) Tango Lemon', '10) Fanta Orange', '11) Cherry Coca Cola', '12) Pepsi Original', '13) Fanta Strawberry', '14) Chupa Chupa Strawberry', '15) Fanta Berry', '16) Chupa Chupa Grape', '17) Stawberry Mario', '18) Duracell', '19) Bomba', '20) Mr Blobby']

for num in range(1,21):
  numbers.append(num)
  
print('Hello, thank you for ordering drinks with us. Our drinks are labelled 1-20, choose which one you want. At the end of your order you can just type in 0 to end your order!')
for i in drinks:
  print((i))
  
while finished == False:
  try:
    answer = int(input('What drink do you want? 1-20?  '))
    if answer in numbers:
      confirmation = input('You have entered drink ' + str(answer) + ' Yes/No/0')
      if confirmation.upper() == 'YES':
        list.append(answer)
      elif confirmation.upper() == 'NO': 
        print('That number has been taken off you order, continue')
      elif confirmation == '0': 
        list.append(answer)
        print(list)
        break
    else:
      print('Sorry we do not have that drink, try again')
  except:
    print('I don\'t understand, please place your order again')